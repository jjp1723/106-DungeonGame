﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// The Character Abstract Class. 
/// Saumil is responsible for this class/ its child classes
/// Refer to Trello or ask questions in discord
/// </summary>
namespace GDAPS2Group4
{
    abstract class Character
    {
        private int health;
        private int damage;
        public List<Item> inventory;

        public int Health
        {
            get
            {
                return health;
            }
            set
            {
                health = value;
            }
        }

        public int Damage
        {
            get
            {
                return damage;
            }
            set
            {
                damage = value;
            }
        }

        //Using an index on the character returns the item the character is carrying in that slot
        public Item this[int i]
        {
            get { return inventory[i]; }
            set { inventory[i] = value; }
        }

        public Character(int health, int damage)
        {
            this.health = health;
            this.damage = damage;
            inventory = new List<Item>();
        }

        public abstract void Add(Item item);
    }
}
