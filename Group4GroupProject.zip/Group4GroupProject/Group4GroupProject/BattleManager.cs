﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GDAPS2Group4;
using Microsoft.Xna.Framework.Graphics;

namespace Group4GroupProject
{
    //Creating an enum to help determine whose turn it is
    enum BattleState
    {
        PlayerTurn,
        EnemyTurn,
        Ended
    }



    class BattleManager
    {
        // ----- Fields -----
        protected Player player;
        protected Enemy enemy;
        protected EnemyRoom room;
        protected BattleState state;
        protected ButtonManager buttons;

        //ToDo: Add more fields related to player and enemy statistics



        // ----- Field Properties -----

        //Player Property
        public Player Player
        {
            get
            {
                return player;
            }
            set
            {
                player = value;
            }
        }

        //Enemy Property
        public Enemy Enemy
        {
            get
            {
                return enemy;
            }
            set
            {
                enemy = value;
            }
        }

        //EnemyRoom Property
        public EnemyRoom EnemyRoom
        {
            get
            {
                return room;
            }
            set
            {
                room = value;
            }
        }

        //ButtonManager Property
        public ButtonManager ButtonManager
        {
            get
            {
                return buttons;
            }
            set
            {
                buttons = value;
            }
        }

        //BattleState Property
        public BattleState BattleState
        {
            get
            {
                return state;
            }
            set
            {
                state = value;
            }
        }

        //ToDo: Add field properties for any added fields



        // ----- Constructor -----
        public BattleManager(Player user, EnemyRoom er, ButtonManager butt)
        {
            player = user;
            enemy = er.Enemy;
            room = er;
            buttons = butt;
            state = BattleState.PlayerTurn;
        }



        //Battle Method
        public void Battle()
        {
            //Using a switch to check the state of the battle
            switch(state)
            {
                //When it's the player's turn
                case BattleState.PlayerTurn:
                    //Drawing the buttons related to player actions
                    buttons.BattleDraw();

                    //If the Attack Button is clicked, the player's attack method is called, the Attack Button's clicked field is set to false, and it becomes the enemy's turn
                    if(buttons.Attack.Clicked)
                    {
                        player.Attack(enemy);
                        buttons.Attack.Clicked = false;
                        state = BattleState.EnemyTurn;
                    }

                    //If the Guard Button is clicked, the player's guard method is called and the Guard Button's clicked field is set to false
                    if(buttons.Guard.Clicked)
                    {
                        player.Guard(enemy);
                        buttons.Guard.Clicked = false;
                    }

                    //If the Item Button is clicked, the button's DisplayInventory Method is called
                    if(buttons.Item.Clicked)
                    {
                        player.DisplayInventory();
                        buttons.Item.Clicked = false;
                        state = BattleState.EnemyTurn;
                    }

                    //If the Flee Button is clicked, the Flee Button's clicked field is set to false and the player's Flee method is called
                    if (buttons.Flee.Clicked)
                    {
                        buttons.Flee.Clicked = false;

                        //If the Player's flee method returns true, then the battle ends, otherwise it becomes the enemy's turn
                        if(player.Flee())
                        {
                            state = BattleState.Ended;

                            //ToDo: Add more code relevent to escaping a battle
                        }
                        else
                        {
                            state = BattleState.EnemyTurn;
                        }
                    }

                    //Checking if the either the player's or enemy's health has dropped below zero, and if they have, the battle ends
                    if(player.Health < 0 || enemy.Health < 0)
                    {
                        state = BattleState.Ended;
                    }
                    break;



                //When it's the enemy's turn
                case BattleState.EnemyTurn:
                    //The enemy attacks the player, lowering the player's health
                    player.Health -= enemy.Damage;

                    //Checking if the either the player's or enemy's health has dropped below zero, and if they have, the battle ends
                    if (player.Health < 0)
                    {
                        state = BattleState.Ended;
                    }
                    break;
            }
        }
    }
}
