﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// The Room Class. 
/// Zack is responsible for this class/ its child classes
/// Refer to Trello or ask questions in discord
/// </summary>
namespace GDAPS2Group4
{
    class Room
    {
        // Field for num of exits
        private int numExits;
        public int Exits
        {
            get { return numExits; }
            set { numExits = value; }
        }

        protected bool special;

        // True if there is an exit in that direction
        private Room exitNorth;
        private Room exitSouth;
        private Room exitEast;
        private Room exitWest;

        //Properties
        public Room North { get { return exitNorth; } set { exitNorth = value; } }
        public Room East { get { return exitEast; } set { exitEast = value; } }
        public Room West { get { return exitWest; } set { exitWest = value; } }
        public Room South { get { return exitSouth; } set { exitSouth = value; } }
        public bool Special { get { return special; } }
        // Position X
        private int roomPosX;
        public int RoomPosX
        {
            get { return roomPosX; }
            set { roomPosX = value; }
        }

        // Position Y
        private int roomPosY;
        public int RoomPosY
        {
            get { return roomPosY; }
            set { roomPosY = value; }
        }

        private Boolean inRoom;

        public Room(int x, int y)
        {
            numExits = 0;
            RoomPosX = x;
            RoomPosY = y;
            North = null;
            East = null;
            West = null;
            South = null;
        }
    }
}
