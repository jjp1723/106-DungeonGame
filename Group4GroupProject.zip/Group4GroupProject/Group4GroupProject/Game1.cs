﻿using GDAPS2Group4;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Group4GroupProject
{
    /// <summary>
    /// Zach was here
    /// 
    /// Vincent was here
    /// John was here
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Texture2D spriteTest;
        private MapManager mapManager;
        private Random rng;

        // States for the game
        enum GameState
        {
            Menu,
            Explore, 
            Combat,
            Death
        }

        // Enum varible
        private GameState gameState;

        // Keyboard state's
        private KeyboardState kbState;
        private KeyboardState previousKbState;

        // Player for the game
        private Player p1;
        private Enemy e1;

        // Player and Enemy Rectangle
        private Rectangle p1Rect;
        private Rectangle e1Rect;

        // Starting position for the player rectangle
        private int playerStartX;
        private int playerStartY;

        // What direction should the player move
        private Left left;
        private Right right;
        private Forward forward;
        private Back back;

        // SpriteFont
        private SpriteFont gameFont;

        private List<Rectangle> enemyRooms;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            rng = new Random();
            mapManager = new MapManager(rng);

            // Making a new player and setting menu to begin
            p1 = new Player(100, 100, 50, 50, 100, 50);
            // Making new enemy
            e1 = new Enemy(100, 40, 20);

            p1.X = mapManager.Rooms.GetLength(0)  /2;
            p1.Y = mapManager.Rooms.GetLength(1) /2;
            // List of enemy rooms
            enemyRooms = new List<Rectangle>();

            this.IsMouseVisible = true;
            gameState = GameState.Menu;
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            spriteTest = Content.Load<Texture2D>("square");

            p1Rect = new Rectangle(p1.X*10, p1.Y*10, 10, 10);
            e1Rect = new Rectangle(mapManager.Rooms.GetLength(0) * 5 - 10, mapManager.Rooms.GetLength(1) * 5 - 10, 10, 10);

            left = new Left(Content.Load<Texture2D>("Left Button"), new Rectangle(300, 00, 200, 200), Color.White, p1,mapManager.Rooms);
            forward = new Forward(Content.Load<Texture2D>("Forward Button"), new Rectangle(300, 200, 200, 200), Color.White, p1, mapManager.Rooms);
            right = new Right(Content.Load<Texture2D>("Right Button"), new Rectangle(500, 200, 200, 200), Color.White, p1, mapManager.Rooms);
            back = new Back(Content.Load<Texture2D>("Back Button"), new Rectangle(500, 00, 200, 200), Color.White, p1, mapManager.Rooms);
            gameFont = Content.Load<SpriteFont>("GameFont");
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            kbState = Keyboard.GetState();
            // Switching game states
            switch (gameState)
            {
                case GameState.Menu:
                    
                    if (SingleKeyPress(Keys.Enter))
                    {
                        mapManager.Rebuild();
                        gameState = GameState.Explore;
                    }
                    break;

                // Only Leave when entering enemy encounter
                case GameState.Explore:
                    left.Update();
                    right.Update();
                    forward.Update();
                    back.Update();

                    if (mapManager.Rooms[p1.X,p1.Y] is EnemyRoom)
                    {
                        if (((EnemyRoom)mapManager.Rooms[p1.X, p1.Y]).Enemy.Alive)
                        {
                            gameState = GameState.Combat;
                        }
                    }
                    break;
                case GameState.Combat:
                    // If dies, game over
                    if(p1.Health <= 0)
                    {
                        gameState = GameState.Death;
                    }
                    // If enemy dies, continue to explore
                    if(((EnemyRoom)mapManager.Rooms[p1.X, p1.Y]).Enemy.Health <= 0)
                    {
                        ((EnemyRoom)mapManager.Rooms[p1.X, p1.Y]).Enemy.Alive = false;
                        gameState = GameState.Explore;
                    }
                    if (SingleKeyPress(Keys.Escape))
                    {
                        Debug.WriteLine("Kill switch activated");
                        ((EnemyRoom)mapManager.Rooms[p1.X, p1.Y]).Enemy.Health = 0;
                        ((EnemyRoom)mapManager.Rooms[p1.X, p1.Y]).Enemy.Alive = false;
                    }
                    if (SingleKeyPress(Keys.Back))
                    {
                        p1.Health = 0;
                    }
                    break;
                // If escape is pressed then go back to main menu
                case GameState.Death:
                    if (SingleKeyPress(Keys.A))
                    {
                        gameState = GameState.Menu;
                        mapManager.Clear();
                        mapManager.Rebuild();
                    }
                    break;
            }
            previousKbState = kbState;
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            
            spriteBatch.Begin();

            // Adding text to menu to make to start up the game
            if(gameState == GameState.Menu)
            {
                spriteBatch.DrawString(gameFont, "Welcome to The Group 4 Game!!!", new Vector2(GraphicsDevice.Viewport.Width / 2, GraphicsDevice.Viewport.Height / 2), Color.Black);
                spriteBatch.DrawString(gameFont, "Use arrow keys to move", new Vector2(GraphicsDevice.Viewport.Width / 2, GraphicsDevice.Viewport.Height / 2 + 50), Color.Black);
                spriteBatch.DrawString(gameFont, "Press 'Enter' to Continue...", new Vector2(GraphicsDevice.Viewport.Width / 2, GraphicsDevice.Viewport.Height / 2 + 100), Color.Black);
            }
            if(gameState == GameState.Death)
            {
                spriteBatch.DrawString(gameFont,"ur dead lol", new Vector2(GraphicsDevice.Viewport.Width / 2, GraphicsDevice.Viewport.Height / 2 + 100), Color.Black);
                spriteBatch.DrawString(gameFont, "press A to go back to main menu", new Vector2(GraphicsDevice.Viewport.Width / 2, GraphicsDevice.Viewport.Height / 2 + 200), Color.Black);
            }
            // Draws in the game state
            // *** Change the combat condition, just have to determine placement
            if (gameState == GameState.Explore)
            {
                left.Draw(spriteBatch);
                right.Draw(spriteBatch);
                forward.Draw(spriteBatch);
                back.Draw(spriteBatch);


                for (int i = 0; i < mapManager.Rooms.GetLength(0); i++)
                {
                    for (int j = 0; j < mapManager.Rooms.GetLength(1); j++)
                    {
                        if (mapManager[i, j] == null)
                        {
                            // No Room == Black
                            spriteBatch.Draw(spriteTest, new Rectangle(i * 10, j * 10, 10, 10), Color.Black);
                        }
                        else if (mapManager[i, j] is BossRoom)
                        {

                            spriteBatch.Draw(spriteTest, new Rectangle(i * 10, j * 10, 10, 10), Color.Red);
                        }
                        else if (mapManager[i, j] is ShopRoom)
                        {

                            spriteBatch.Draw(spriteTest, new Rectangle(i * 10, j * 10, 10, 10), Color.Green);
                        }
                        else if (mapManager[i, j] is ItemRoom)
                        {

                            spriteBatch.Draw(spriteTest, new Rectangle(i * 10, j * 10, 10, 10), Color.Blue);
                        }
                        else if (mapManager[i, j] is EnemyRoom)
                        {
                            enemyRooms.Add(new Rectangle(i * 10, j * 10, 10, 10));
                            spriteBatch.Draw(spriteTest, new Rectangle(i * 10, j * 10, 10, 10), Color.Orange);
                        }
                        else
                        {
                            // Yes Room == White
                            spriteBatch.Draw(spriteTest, new Rectangle(i * 10, j * 10, 10, 10), Color.White);
                        }
                    }
                }

                // Draws players and enemy
                spriteBatch.Draw(spriteTest, new Rectangle(p1.X*10,p1.Y*10,10,10), Color.Purple);
                //spriteBatch.Draw(spriteTest, e1Rect, Color.BlueViolet);
            }

            if(gameState == GameState.Combat)
            {
                spriteBatch.DrawString(gameFont, "You are in combat, what's up", new Vector2(GraphicsDevice.Viewport.Width / 2, GraphicsDevice.Viewport.Height / 2), Color.Black);
            }

            spriteBatch.End();
            base.Draw(gameTime);
        }

        // Key press method
        public bool SingleKeyPress(Keys key)
        {
            if (kbState.IsKeyDown(key) && previousKbState.IsKeyUp(key))
            {
                return true;
            }
            return false;
        }

        // What moves the player, allows it to encounter stuff
        public void MovePlayer()
        {
            KeyboardState board = Keyboard.GetState();

            if (board.IsKeyDown(Keys.Right))
            {
                p1Rect.X += 2;
            }
            if (board.IsKeyDown(Keys.Left))
            {
                p1Rect.X -= 2;
            }
            if (board.IsKeyDown(Keys.Up))
            {
                p1Rect.Y -= 2;
            }
            if (board.IsKeyDown(Keys.Down))
            {
                p1Rect.Y += 2;
            }
        }
    }
}
