﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// The Player Class. Inherits from Character.
/// Refer to Trello or ask questions in discord
/// </summary>
namespace GDAPS2Group4
{
    class Player : Character
    {
        // ----- Fields -----
        private int xPos;
        private int yPos;
        private int money;
        private int level;
        private int block;
        private int fleechance;

        //Local coord vs Global Coord Field
        private Direction facingDirection;



        // ----- Field Properties -----

        //X Property
        public int X
        {
            get
            {
 
               return xPos;
            }
            set
            {
                xPos = value;
            }
        }

        //Y Property
        public int Y {
            get
            {
                return yPos;
            }
            set
            {
                yPos = value;
            }
        }

        //Direction Property
        public Direction Direction
        {
            get
            {
                return facingDirection;
            }
            set
            {
                facingDirection = value;
            }
        }

        //Money Property
        public int Money
        {
            get
            {
                return money;
            }
            set
            {
                money = value;
            }
        }

        //Level Property
        public int Level
        {
            get
            {
                return level;
            }
            set
            {
                level = value;
            }
        }

        //Guard Property
        public int Block
        {
            get
            {
                return block;
            }
            set
            {
                block = value;
            }
        }

        //FleeChance Property
        public int FleeChance
        {
            get
            {
                return fleechance;
            }
            set
            {
                fleechance = value;
            }
        }


        
        // ----- Constructor -----
        public Player(int hp, int str, int x, int y, int health, int damage) : base(health, damage)
        {
            Health = hp;
            Damage = str;
            xPos = x;
            yPos = y;
            facingDirection = Direction.North;
        }



        // ----- Methods -----

        //Add Method
        public override void Add(Item item)
        {
            inventory.Add(item);
        }

        //Attack Method
        public void Attack(Enemy enemy)
        {
            enemy.Health -= Damage;
        }

        //Guard Method
        public void Guard(Enemy enemy)
        {
            Health -= enemy.Damage - block;
        }

        //Display Inventory Method
        public void DisplayInventory()
        {
            //ToDo: Determine a way to display the user's inventory to the screen
        }

        //Flee Method
        public bool Flee()
        {
            Random rng = new Random();
            return rng.Next(100) < fleechance;
        }
    }
}
