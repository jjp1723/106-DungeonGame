﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Item class for all items found in the game or in the shop
/// </summary>
namespace GDAPS2Group4
{
    enum Items
    {
        Consumable = 0,
        Weapon = 1,
        Armor = 2,
        SmokeBomb,
        HealingPotion,
        FireBomb,
        Broadsword,
        Battleaxe,
        Dagger,
        Leather,
        Chainmail,
        Iron
        
    }

    public class Item
    {
        // The item type
        private Items itemType;

        // The current item in that type
        private Items item;

        // Cost for item at a shop
        private int cost;

        // Name of item
        private String name;

        // Tooltype
        private String tooltip;
        private Random rng;
        public int Cost
        {
            get { return cost; }
        }

        public String Name
        {
            get { return name; }
        }

        // Regular constructor for items found in a room
        public Item(int typeItem,  Random rng)
        {
            if (typeItem == 0)
            {
                itemType = Items.Consumable;
                item = (Items) rng.Next((int)Items.SmokeBomb, (int)Items.FireBomb+1);
            }
            if (typeItem == 1)
            {
                itemType = Items.Weapon;
                item = (Items)rng.Next((int)Items.Broadsword,(int)Items.Dagger+ 1);
            }
            if(typeItem == 2)
            {
                itemType = Items.Armor;
                item = (Items)rng.Next((int)Items.Leather,(int)Items.Iron + 1);
            }
        }

        // Constructor for items found in the shop room
        public Item(int typeItem, Random rng , int cost)
        {
            this.cost = cost;

            // Setting what kind of item this item is
            if (typeItem == 0)
            {
                itemType = Items.Consumable;
                item = (Items)rng.Next((int)Items.SmokeBomb, (int)Items.FireBomb + 1);
            }
            if (typeItem == 1)
            {
                itemType = Items.Weapon;
                item = (Items)rng.Next((int)Items.Broadsword, (int)Items.Dagger + 1);
            }
            if (typeItem == 2)
            {
                itemType = Items.Armor;
                item = (Items)rng.Next((int)Items.Leather, (int)Items.Iron + 1);
            }
        }

        public override string ToString()
        {
            return item.ToString() + " it is a " + itemType.ToString();
        }
    }
}
