﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Group4GroupProject
{
    class Button
    {
        // ----- Fields -----
        protected Texture2D texture;
        protected Rectangle position;
        protected Color color;
        protected bool clicked;



        // ----- Fields Propteries -----

        //Texture Property
        public Texture2D Texture
        {
            get
            {
                return texture;
            }
            set
            {
                texture = value;
            }
        }

        //Rectangle Property
        public Rectangle Position
        {
            get
            {
                return position;
            }
            set
            {
                position = value;
            }
        }

        //X Property
        public int X
        {
            get
            {
                return position.X;
            }
            set
            {
                position.X = value;
            }
        }

        //Y Property
        public int Y
        {
            get
            {
                return position.Y;
            }
            set
            {
                position.Y = value;
            }
        }

        //Color Property
        public Color Color
        {
            get
            {
                return color;
            }
            set
            {
                color = value;
            }
        }

        //Clicked Property
        public bool Clicked
        {
            get
            {
                return clicked;
            }
            set
            {
                clicked = value;
            }
        }



        // ----- Constructor -----
        public Button(Texture2D image, Rectangle rect, Color hue)
        {
            texture = image;
            Position = rect;
            color = hue;
            clicked = false;
        }



        // ----- Methods -----

        /// <summary>
        /// This is a temporary placeholder. Will need to be filled out eventually.
        /// </summary>
        public void Onclick()
        {
            clicked = true;
        }


        //Draw Method
        public void Draw(SpriteBatch sb)
        {
            sb.Draw(texture, position, color);
        }
    }
}
