﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// The Enemy Class. Inherits from Character
/// Refer to Trello or ask questions in discord
/// </summary>
namespace GDAPS2Group4
{
    class Enemy : Character
    {
        private Item weapon;
        private int wallet;
        private int xPos;
        private int yPos;
        private bool alive;
        public int X
        {
            get
            {
 
               return xPos;
            }
            set
            {
                xPos = value;
            }
        }

        public int Y {
            get
            {
                return yPos;
            }
            set
            {
                yPos = value;
            }
        }

        public bool Alive
        {
            get { return Health > 0; }
            set { alive = value; }
        }

        public override void Add(Item item)
        {
            inventory.Add(item);
        }

        public Enemy(int health, int damage, int wallet) : base(health, damage)
        {
            Add(weapon); 
            this.wallet = wallet;
            alive = true;
        }

        public void Attack(Player player)
        {
            player.Health -= Damage;        
        }
    }
}
