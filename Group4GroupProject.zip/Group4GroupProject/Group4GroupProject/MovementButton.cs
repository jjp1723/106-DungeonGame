﻿using GDAPS2Group4;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4GroupProject
{
    class MovementButton : Button
    {
        // ----- Fields ------
        protected Player player;
        private MouseState previousState;
        protected Room[,] rooms;
        // ----- Fields Properties -----

        //Player Property
        public Player Player
        {
            get
            {
                return player;
            }
            set
            {
                player = value;
            }
        }



        // ----- Constructor -----
        public MovementButton(Texture2D image, Rectangle rect, Color hue,Player p,Room[,] r) : base(image, rect, hue)
        {
            player = p;
            previousState = Mouse.GetState();
            rooms = r;
        }

        /// <summary>
        /// Moves player in direction that corresponds to the button
        /// </summary>
        public virtual void Move()
        {
            
        }

        /// <summary>
        /// Should update on gameTime, if clicked while game is running in Explore mode, it should move player to adjacent room
        /// </summary>
        public void Update()
        {
            MouseState ms = Mouse.GetState();
            // If clicked
            if (ms.LeftButton == ButtonState.Pressed && previousState.LeftButton == ButtonState.Released)
            {
                if (this.Position.Contains(ms.Position))
                {
                    Move();
                }
            }
            previousState = ms;
        }
    }
}
