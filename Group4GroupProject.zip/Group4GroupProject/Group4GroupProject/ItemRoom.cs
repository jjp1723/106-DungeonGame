﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//This is the item room class - inherits from the room class
namespace GDAPS2Group4 
{
    class ItemRoom : Room
    {
        // Simple pass to room
        public ItemRoom(int x, int y) : base(x, y)
        {
            special = true;
        }
    }
}
